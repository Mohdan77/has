<?php


namespace AmoCRM;


class Introvert
{


    public static function Debug($data)
    {
        echo '<pre>';print_r($data);die;
    }

    public function getSuccessLeadsCost($api, $date_from, $date_to)
    {

        $data = [];

        while (true){
            $result = $api->lead->getAll(null,  142, null, null, 250, count($data));

            $data = array_merge($data, $result['result']);

            if (count($result['result']) < 250){
                break;
            }

        }

        $cost = 0;

        foreach ($data as $item){

            if ($item['date_close'] >= $date_from->getTimestamp() && $item['date_close'] <= $date_to->getTimestamp()){
                $cost += $item['price'];
            }
        }

        return $cost;
    }

    public function getClients()
    {
        return [
            [
                'id' => 2123,
                'name' => 'Magomed',
                'api' => '23bc075b710da43f0ffb50ff9e889aede'
            ],
            [
                'id' => 9585804,
                'name' => 'introverttest',
                'api' => '23bc075b710da43f0ffb50ff9e889aed'
            ],
            [
                'id' => 21233,
                'name' => 'Gena',
                'api' => '23bc075b710da43f0ffb50ff9e889aede12'
            ],
        ];

    }
}