<?php

include __DIR__ . '/vendor/autoload.php';

set_time_limit(0);
ini_set('max_execution_time',0);



if (isset($_GET['date_from'], $_GET['date_to'])) {

$api = new Introvert\ApiClient();
$introvert = new \AmoCRM\Introvert();
$data = [];
$cost = 0;

foreach ($introvert->getClients() as $value) {


    Introvert\Configuration::getDefaultConfiguration()->setApiKey('key', $value['api']) ;

    try {
        $account = $api->account->info();
    }catch (Exception $exception){
        $data[$value['id']]['id'] = $value['id'];
        $data[$value['id']]['name'] = $value['name'];
        $data[$value['id']]['price'] = 'Не валидный ключ';

        continue;
    }


    $data[$account['result']['id']]['id'] = $account['result']['id'];
    $data[$account['result']['id']]['name'] = $account['result']['name'];

    $date_from = DateTime::createFromFormat(
        'Y-m-d',
        $_GET['date_from'],
        new DateTimeZone('UTC')
    );

    $date_to = DateTime::createFromFormat(
        'Y-m-d',
        $_GET['date_to'],
        new DateTimeZone('UTC')
    );

    $cost += $data[$account['result']['id']]['price'] = $introvert->getSuccessLeadsCost($api, $date_from, $date_to);
}


}


?>


<form action="">
    <label for="date_from">От</label>
    <input type="date" id="date_from" name="date_from">
    <label for="date_to">До</label>
    <input type="date" id="date_to" name="date_to">
    <input type="submit">
</form>

<table>
    <thead>
        <th>ID клиента</th>
        <th>Название клиента</th>
        <th>Сумма успешных сделок(за период)</th>
    </thead>
    <tbody>
    <?php foreach ($data as $item): ?>
    <tr>
        <td><?php echo $item['id']?></td>
        <td><?php echo $item['name']?></td>
        <td><?php echo $item['price']?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
    <tbody>
    <td>Всего <?=$cost?></td>
    </tbody>
</table>

<style>
    td{
        border: 1px solid black;
    }
</style>